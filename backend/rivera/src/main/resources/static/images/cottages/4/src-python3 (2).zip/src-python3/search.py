# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
U ovom fajlu cete implementirati algoritme pretrage, koje pozivaju Pacman agenti u searchAgents.py
"""

import util

class SearchProblem:
    """
    Ova klasa definise strukturu problema pretrage, ali ne implementira nijednu od metoda (apstraktna klasa).
    NE TREBA nista u ovoj klasi da menjate.
    """

    def getStartState(self):
        """
        Vraca pocetno stanje problema pretrage.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Stanje pretrage

        Vraca True ako i samo ako je prosledjeno stanje validno ciljno stanje.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Stanje pretrage

        Za prosledjeno stanje, ova funkcija bi trebalo da vrati listu tripleta (successor, action, stepCost),
        gde je 'successor' sledece stanje u odnosu na trenutno (prosledjeno funkciji),
        'action' akcija koja je potrebna da bi se doslo u to stanje i
        'stepCost' inkrementalna cena za razvoj algoritma do successor-a.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: Lista akcija koje je potrebno izvrsiti
        Ova metoda vraca ukupnu cenu odredjene sekvence akcija
        Sekvenca akcija se mora sastojati od legalnih pokreta
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Vraca sekvencu pokreta koji daju resenje za tinyMaze. Za bilo koji drugi lavirint ova sekvenca ce biti neispravna,
    tako da je koristite iskljucivo za tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Najpre pretrazuje najdublje cvorove u stablu.

    Isprobajte i koristite sledece:
    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    # TODO 1: Implementirati DFS
    raise util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Najpre pretrazuje najplice cvorove u stablu."""
    # TODO 2: Implementirati BFS
    raise util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    Heuristicka funkcija procenjuje cenu od trenutnog stanja do najblizeg sledeceg stanja u prostoru pretrage.
    Ova heuristika je trivijalna.
    """
    return 0


def aStarSearch(problem, heuristic=nullHeuristic):
    # TODO 3: Implementirati A*
    f = lambda path: problem.getCostOfActions([state[1] for state in path][1:0]) + heuristic(path[-1][0], problem)
    data_structure = util.PriorityQueueWithFunction(f)

    # data_structure = util.PriorityQueue()

    path = [(problem.getStartState(), 'Stop', 0)]  # da stignemo tamo
    visited = []
    # priority = heuristic(path[-1][0], problem) + problem.getCostOfActions([state[1] for state in path][1:0])
    data_structure.push(path)

    while not data_structure.isEmpty():
        path = data_structure.pop()
        current_state = path[-1][0]
        if problem.isGoalState(current_state):
            return [state[1] for state in path][1:]

        if current_state not in visited:
            visited.append(current_state)
            for successor in problem.getSuccessors(current_state):
                if successor[0] not in visited:
                    successorPath = path[:]
                    successorPath.append(successor)
                    # priority = heuristic(path[-1][0], problem) + problem.getCostOfActions([state[1] for state in path][1:0])
                    data_structure.push(successorPath)
    return []
    #raise util.raiseNotDefined()
"""

def aStarSearch(problem, heuristic=nullHeuristic):
    # Najpre pretrazuje cvor koji ima najnizu kombinovanu cenu i heuristiku.
    # TODO 3: Implementirati A*
    cost = lambda path: problem.getCostOfActions([state[1] for state in path][1:]) + heuristic(path[-1][0], problem)

    priorityQueue = util.PriorityQueueWithFunction(cost)
    return generalSearch(problem, priorityQueue)

def generalSearch(problem, data_structure):
    
    #:param problem: struktura stanja
    #:param data_structure: struktura podataka koja se koristi (Stack, Queue, ...)
    #:return: pravci kretanja i cene
    
    visited = []
    path = list()
    data_structure.push([(problem.getStartState(), "Stop", 0)])

    print("Start: ", problem.getStartState())

    while not data_structure.isEmpty():
        path = data_structure.pop()
        current_state = path[-1][0]
        print("Going direction ", path[-1][1])
        print("State is ", current_state)

        if problem.isGoalState(current_state):
            return [state[1] for state in path][1:]

        if current_state not in visited:
            visited.append(current_state)

            for successor in problem.getSuccessors(current_state):
                if successor[0] not in visited:
                    successorPath = path[:]
                    successorPath.append(successor)
                    data_structure.push(successorPath)
    return []

"""

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
